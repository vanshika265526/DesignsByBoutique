"use client";

import { useRef } from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, useScroll, useTransform, useReducedMotion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { initialChapters } from "@/data/products";

export default function ChapterTimeline() {
    const reduce = useReducedMotion();
    const ref = useRef(null);
    const { scrollYProgress } = useScroll({
        target: ref,
        offset: ["start 55%", "end 65%"],
    });
    const fill = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);
    const chapters = initialChapters || [];

    return (
        <section className="relative overflow-hidden bg-boutique-rose-dark text-white py-20 md:py-28">
            {/* Ambient glows */}
            <div className="pointer-events-none absolute -top-24 -right-24 w-96 h-96 rounded-full bg-boutique-gold/10 blur-3xl" />
            <div className="pointer-events-none absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-boutique-rose-light/25 blur-3xl" />

            <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
                {/* Header */}
                <div className="text-center max-w-2xl mx-auto mb-16 md:mb-24">
                    <p className="text-[11px] uppercase tracking-[0.3em] text-boutique-gold-light font-semibold mb-4">
                        The Journey
                    </p>
                    <h2 className="font-serif-editorial text-3xl sm:text-4xl md:text-5xl font-light leading-tight">
                        For Every Chapter <span className="italic">of Her Story</span>
                    </h2>
                    <p className="mt-5 text-sm sm:text-base text-white/70 font-light leading-relaxed">
                        From her first festive celebrations to bridal vows, into motherhood, and her
                        little one&apos;s earliest milestones — one boutique, dressing every chapter of her life.
                    </p>
                </div>

                {/* Timeline */}
                <div ref={ref} className="relative">
                    {/* Spine track */}
                    <div className="absolute top-0 bottom-0 left-6 md:left-1/2 md:-translate-x-1/2 w-px bg-white/15" />
                    {/* Spine fill — grows with scroll */}
                    <motion.div
                        style={{ height: reduce ? "100%" : fill }}
                        className="absolute top-0 left-6 md:left-1/2 md:-translate-x-1/2 w-px bg-gradient-to-b from-boutique-gold-light via-boutique-gold to-boutique-rose-light"
                    />

                    <div className="space-y-14 md:space-y-24">
                        {chapters.map((ch, i) => {
                            const left = i % 2 === 0;
                            return (
                                <div key={ch.id || i} className="relative">
                                    {/* Dot */}
                                    <motion.span
                                        initial={reduce ? false : { scale: 0 }}
                                        whileInView={{ scale: 1 }}
                                        viewport={{ once: true, margin: "-80px" }}
                                        transition={{ type: "spring", stiffness: 260, damping: 18 }}
                                        className="absolute z-10 left-6 md:left-1/2 -translate-x-1/2 top-7 md:top-1/2 md:-translate-y-1/2 w-4 h-4 rounded-full bg-boutique-gold ring-4 ring-boutique-rose-dark"
                                    />

                                    {/* Card */}
                                    <motion.div
                                        initial={reduce ? false : { opacity: 0, y: 44 }}
                                        whileInView={{ opacity: 1, y: 0 }}
                                        viewport={{ once: true, margin: "-80px" }}
                                        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                                        className={`pl-16 md:pl-0 md:w-[calc(50%-2.75rem)] ${
                                            left ? "md:mr-auto md:pr-2" : "md:ml-auto md:pl-2"
                                        }`}
                                    >
                                        <div className="group rounded-2xl overflow-hidden bg-white/[0.06] border border-white/10 backdrop-blur-sm shadow-xl">
                                            {/* Image */}
                                            <div className="relative aspect-[16/10] overflow-hidden">
                                                <Image
                                                    src={ch.image}
                                                    alt={`${ch.title} — ${ch.categoryName}`}
                                                    fill
                                                    sizes="(max-width: 768px) 90vw, 42vw"
                                                    className="object-cover object-center transition-transform duration-[900ms] ease-out group-hover:scale-105"
                                                />
                                                <div className="absolute inset-0 bg-gradient-to-t from-boutique-rose-dark/80 via-boutique-rose-dark/10 to-transparent" />
                                                <span className="absolute top-3 left-3 text-[10px] uppercase tracking-[0.18em] bg-boutique-gold text-boutique-rose-dark font-bold px-2.5 py-1 rounded-full">
                                                    {ch.categoryName}
                                                </span>
                                                <span className="absolute -bottom-1 right-4 font-serif-editorial text-7xl font-light text-white/20 leading-none select-none">
                                                    {ch.number}
                                                </span>
                                            </div>

                                            {/* Text */}
                                            <div className={`p-6 ${left ? "md:text-right" : "md:text-left"}`}>
                                                <p className="text-[11px] uppercase tracking-[0.22em] text-boutique-gold-light font-semibold">
                                                    Chapter {ch.number}
                                                </p>
                                                <h3 className="font-serif-editorial text-2xl md:text-3xl font-medium mt-1">
                                                    {ch.title}
                                                </h3>
                                                <p className="text-xs text-white/55 italic mt-1">{ch.subtitle}</p>
                                                <p className="text-sm text-white/70 font-light mt-3 leading-relaxed line-clamp-3">
                                                    {ch.description}
                                                </p>
                                                <Link
                                                    href={`/collections/${ch.categorySlug}`}
                                                    className={`mt-4 inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[0.15em] text-boutique-gold-light hover:text-white transition-colors ${
                                                        left ? "md:flex-row-reverse" : ""
                                                    }`}
                                                >
                                                    <span>Discover {ch.categoryName}</span>
                                                    <ArrowRight className="w-3.5 h-3.5" />
                                                </Link>
                                            </div>
                                        </div>
                                    </motion.div>
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* Closing CTA */}
                <div className="text-center mt-16 md:mt-24">
                    <Link
                        href="/collections"
                        className="inline-flex items-center gap-2 bg-boutique-gold hover:bg-boutique-gold-light text-boutique-rose-dark px-8 py-3.5 text-xs font-semibold tracking-[0.2em] uppercase transition-colors"
                    >
                        Explore Every Collection
                    </Link>
                </div>
            </div>
        </section>
    );
}
