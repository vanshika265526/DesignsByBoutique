/**
 * Designs by Nisha — Product & Collection Dataset & Shared Data Helpers
 * Connects the public website directly to the DB engine for single-source-of-truth.
 */

export const initialCategories = [
    {
        "id": "suits-anarkalis",
        "name": "Suits & Anarkalis",
        "slug": "suits-anarkalis",
        "chapter": "her-beginnings",
        "description": "Graceful daily luxury & celebratory silk Anarkali suits.",
        "image": "https://images.pexels.com/photos/4336823/pexels-photo-4336823.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "count": 24,
        "published": true,
        "order": 1
    },
    {
        "id": "bridal-lehengas",
        "name": "Bridal Lehengas",
        "slug": "bridal-lehengas",
        "chapter": "her-forever",
        "description": "Hand-embroidered zardozi bridal masterpieces for her big day.",
        "image": "https://images.pexels.com/photos/12579916/pexels-photo-12579916.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "count": 18,
        "published": true,
        "order": 2
    },
    {
        "id": "haldi-mehendi",
        "name": "Haldi & Mehendi",
        "slug": "haldi-mehendi",
        "chapter": "her-new-chapter",
        "description": "Vibrant yellow kesar lehengas & emerald green shararas.",
        "image": "https://images.pexels.com/photos/23623618/pexels-photo-23623618.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "count": 15,
        "published": true,
        "order": 3
    },
    {
        "id": "maternity-gowns",
        "name": "Maternity Gowns",
        "slug": "maternity-gowns",
        "chapter": "her-motherhood",
        "description": "Featherlight silk maternity gowns & baby shower attire.",
        "image": "/images/maternity/gown-3.png",
        "count": 12,
        "published": true,
        "order": 4
    },
    {
        "id": "baby-clothes",
        "name": "Baby Clothes",
        "slug": "baby-clothes",
        "chapter": "her-little-one",
        "description": "Skin-friendly heirloom baby lehengas & festive kurti sets.",
        "image": "https://images.pexels.com/photos/20263916/pexels-photo-20263916.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "count": 16,
        "published": true,
        "order": 5
    }
];

export const initialChapters = [
    {
        "id": "her-beginnings",
        "number": "01",
        "title": "Her Beginnings",
        "subtitle": "Young Womanhood & Celebrations",
        "description": "Elegance in everyday luxury, college festive days, and light family celebrations.",
        "categorySlug": "suits-anarkalis",
        "categoryName": "Suits & Anarkalis",
        "image": "https://odhni.com/cdn/shop/files/Gemini_Generated_Image_ybvw7yybvw7yybvw.png?v=1779367771&width=1200"
    },
    {
        "id": "her-forever",
        "number": "02",
        "title": "Her New Chapter",
        "subtitle": "Married Life & Festive Ceremonies",
        "description": "Haldi yellow lehengas, emerald Mehendi shararas, and post-wedding dinner sarees.",
        "categorySlug": "haldi-mehendi",
        "categoryName": "Haldi & Mehendi",
        "image": "https://bawreefashions.com/cdn/shop/files/WhatsApp_Image_2025-12-18_at_15.49.23.jpg?v=1766393862&width=1200"
    },
    {
        "id": "her-new-chapter",
        "number": "03",
        "title": "Her Forever",
        "subtitle": "The Quintessential Bride",
        "description": "Heirloom bridal lehengas, royal red velvets, and hand-worked zardozi ensembles.",
        "categorySlug": "bridal-lehengas",
        "categoryName": "Bridal Lehengas",
        "image": "https://img.perniaspopupshop.com/catalog/product/n/k/NKGC072509_1.jpg?impolicy=detailimageprod"
    },
    {
        "id": "her-motherhood",
        "number": "04",
        "title": "Her Motherhood",
        "subtitle": "Nurturing New Life",
        "description": "Custom flowy maternity photoshoot gowns and soft breathable baby shower Anarkalis.",
        "categorySlug": "maternity-gowns",
        "categoryName": "Maternity Gowns",
        "image": "https://themomstore.in/cdn/shop/files/elegant-wine-maternity-lace-gown-3656588.jpg?v=1782110590&width=1000"
    },
    {
        "id": "her-little-one",
        "number": "05",
        "title": "Her Little One",
        "subtitle": "First Milestones & Baby Couture",
        "description": "Zero-scratch lined miniature baby lehengas, Annaprashan outfits, and festive clothes.",
        "categorySlug": "baby-clothes",
        "categoryName": "Baby Clothes",
        "image": "https://wholesalemegamart.com/wp-content/uploads/2026/04/ZSR-3169-KIDS-ETHNIC-WEAR-FOR-GIRLS-WHOLESALE-1.jpeg"
    }
];

export const initialProducts = [
    {
        "id": "prod-01",
        "slug": "gulzar-chanderi-anarkali-set",
        "name": "Gulzar Chanderi Silk Anarkali Set",
        "category": "suits-anarkalis",
        "categoryName": "Suits & Anarkalis",
        "chapter": "her-beginnings",
        "chapterName": "Her Beginnings",
        "price": 7999,
        "originalPrice": 9999,
        "discount": "20% OFF",
        "featured": true,
        "status": "published",
        "image": "https://images.pexels.com/photos/20520368/pexels-photo-20520368.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/20520368/pexels-photo-20520368.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "A breathtaking floor-length Chanderi silk Anarkali in soft blush rose, featuring delicate hand-worked Gota Patti borders, organza dupatta with scalloped edges, and tailored fitted churidar.",
        "shortDescription": "Soft blush rose Chanderi silk Anarkali with Gota Patti embroidery.",
        "details": [
            "Pure Chanderi Silk & Organza Dupatta",
            "Custom sleeve length customization available",
            "Dry Clean Only"
        ]
    },
    {
        "id": "prod-02",
        "slug": "noor-zardozi-straight-suit",
        "name": "Noor Soft Mint Zardozi Kurta Set",
        "category": "suits-anarkalis",
        "categoryName": "Suits & Anarkalis",
        "chapter": "her-beginnings",
        "chapterName": "Her Beginnings",
        "price": 6499,
        "originalPrice": 7999,
        "discount": "20% OFF",
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/16612752/pexels-photo-16612752.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/16612752/pexels-photo-16612752.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Elegant pastel mint straight kurta ensemble rendered in handloom Tussar silk, detailed with fine antique gold Zardozi thread work along the neckline and sleeves.",
        "shortDescription": "Pastel mint straight Tussar silk kurta set with Zardozi detailing.",
        "details": [
            "Handloom Tussar Silk with Net Dupatta",
            "Pants can be customized to straight or palazzo",
            "Dry Clean Only"
        ]
    },
    {
        "id": "prod-03",
        "slug": "rose-royal-embroidered-bridal-lehenga",
        "name": "Rose Royal Heirloom Bridal Lehenga",
        "category": "bridal-lehengas",
        "categoryName": "Bridal Lehengas",
        "chapter": "her-forever",
        "chapterName": "Her Forever",
        "price": 10999,
        "originalPrice": 13999,
        "discount": "20% OFF",
        "featured": true,
        "status": "published",
        "image": "https://images.pexels.com/photos/9419108/pexels-photo-9419108.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/9419108/pexels-photo-9419108.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "An heirloom masterpiece crafted for the quintessential bride. Deep crimson silk lehenga intricately embroidered with Mughal floral motifs, dabka work, zardozi gold threadwork, and paired with double organza dupattas.",
        "shortDescription": "Crimson silk heirloom bridal lehenga with Zardozi & double dupattas.",
        "details": [
            "Pure Mulberry Velvet Silk",
            "Bespoke Made-to-Measure fitting",
            "Custom latkans with wedding date embroidery"
        ]
    },
    {
        "id": "prod-04",
        "slug": "kesar-haldi-yellow-silk-lehenga",
        "name": "Kesar Haldi Sunshine Silk Lehenga",
        "category": "bridal-lehengas",
        "categoryName": "Bridal Lehengas",
        "chapter": "her-forever",
        "chapterName": "Her Forever",
        "price": 8499,
        "originalPrice": 10499,
        "discount": "20% OFF",
        "featured": true,
        "status": "published",
        "image": "https://images.pexels.com/photos/9418537/pexels-photo-9418537.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/9418537/pexels-photo-9418537.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Vibrant mustard yellow raw silk lehenga designed for Haldi and Sangeet festivities. Features mirrored sequin work, gold zari borders, and a featherlight embroidered bandhani dupatta.",
        "shortDescription": "Mustard raw silk Haldi lehenga with mirror sequin work.",
        "details": [
            "Raw Silk & Handloom Bandhani Dupatta",
            "Custom blouse cut and waist fitting",
            "Dry Clean Only"
        ]
    },
    {
        "id": "prod-05",
        "slug": "mehendi-emerald-sharara-set",
        "name": "Emerald Mehendi Embroidered Sharara",
        "category": "haldi-mehendi",
        "categoryName": "Haldi & Mehendi",
        "chapter": "her-new-chapter",
        "chapterName": "Her New Chapter",
        "price": 7999,
        "originalPrice": 9999,
        "discount": "20% OFF",
        "featured": true,
        "status": "published",
        "image": "https://images.pexels.com/photos/31750738/pexels-photo-31750738.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/31750738/pexels-photo-31750738.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "A rich forest green georgette short kurta and dramatic tiered sharara set adorned with intricate mirror work, resham threadwork, and a sheer embroidered scalloped dupatta.",
        "shortDescription": "Forest green georgette sharara set with mirror & resham threadwork.",
        "details": [
            "Viscose Georgette & Soft Net Dupatta",
            "Tiered sharara volume customization",
            "Dry Clean Only"
        ]
    },
    {
        "id": "prod-06",
        "slug": "rooh-blush-draped-saree-gown",
        "name": "Rooh Blush Pre-Stitched Draped Saree",
        "category": "haldi-mehendi",
        "categoryName": "Haldi & Mehendi",
        "chapter": "her-new-chapter",
        "chapterName": "Her New Chapter",
        "price": 8499,
        "originalPrice": 10599,
        "discount": "20% OFF",
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/31750729/pexels-photo-31750729.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/31750729/pexels-photo-31750729.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Modern cocktail and post-wedding occasion wear. A pre-stitched draped satin saree gown in rose taupe paired with a heavily hand-beaded crystal blouse.",
        "shortDescription": "Pre-stitched rose taupe draped saree gown with beaded blouse.",
        "details": [
            "Fluid Micro-Satin & Hand-beaded Net Blouse",
            "Pre-stitched pleats tailored to exact height"
        ]
    },
    {
        "id": "prod-07",
        "slug": "grace-silk-maternity-photoshoot-gown",
        "name": "Grace Powder Pink Silk Maternity Gown",
        "category": "maternity-gowns",
        "categoryName": "Maternity Gowns",
        "chapter": "her-motherhood",
        "chapterName": "Her Motherhood",
        "price": 7999,
        "originalPrice": 9999,
        "discount": "20% OFF",
        "featured": true,
        "status": "published",
        "image": "/images/maternity/gown-1.png",
        "images": [
            "/images/maternity/gown-1.png"
        ],
        "description": "Designed specifically for expecting mothers celebrating maternity photoshoots, baby showers, or grand family functions. Soft empire-waist flowy silhouette with stretchable inner lining and trailing chiffon cape.",
        "shortDescription": "Powder pink empire-waist silk maternity gown with trailing cape.",
        "details": [
            "Hypoallergenic Pure Satin Silk & Sheer Chiffon",
            "Hidden nursing zip & trimester adjustability"
        ]
    },
    {
        "id": "prod-08",
        "slug": "roop-blush-satin-maternity-gown",
        "name": "Roop Blush Satin Slit Maternity Gown",
        "category": "maternity-gowns",
        "categoryName": "Maternity Gowns",
        "chapter": "her-motherhood",
        "chapterName": "Her Motherhood",
        "price": 6999,
        "originalPrice": 8699,
        "discount": "20% OFF",
        "featured": false,
        "status": "published",
        "image": "/images/maternity/gown-2.png",
        "images": [
            "/images/maternity/gown-2.png"
        ],
        "description": "Elegant blush satin maternity gown with subtle side slit, empire waistband, and gentle gather pleats for photographic elegance.",
        "shortDescription": "Blush satin maternity gown with gentle gathers & empire waist.",
        "details": [
            "Luminous Satin & Soft Breathable Lining",
            "Hidden comfort zip"
        ]
    },
    {
        "id": "prod-maternity-03",
        "slug": "aarya-floral-anarkali-maternity-gown",
        "name": "Aarya Floral Hand-Printed Maternity Anarkali",
        "category": "maternity-gowns",
        "categoryName": "Maternity Gowns",
        "chapter": "her-motherhood",
        "chapterName": "Her Motherhood",
        "price": 5999,
        "originalPrice": 7499,
        "discount": "20% OFF",
        "featured": false,
        "status": "published",
        "image": "/images/maternity/gown-3.png",
        "images": [
            "/images/maternity/gown-3.png"
        ],
        "description": "Featherweight Mulmul cotton floral Anarkali maternity gown with delicate Gota work. Ultra-breathable, soothing on sensitive skin, and tailored with extra room for growing bellies.",
        "shortDescription": "100% Mulmul cotton floral Anarkali maternity gown with Gota detail.",
        "details": [
            "100% Organic Hand-printed Mulmul Cotton",
            "Discreet nursing zippers optional"
        ]
    },
    {
        "id": "prod-maternity-04",
        "slug": "kavya-royal-draped-maternity-gown",
        "name": "Kavya Royal Silk Draped Maternity Gown",
        "category": "maternity-gowns",
        "categoryName": "Maternity Gowns",
        "chapter": "her-motherhood",
        "chapterName": "Her Motherhood",
        "price": 8499,
        "originalPrice": 10599,
        "discount": "19% OFF",
        "featured": true,
        "status": "published",
        "image": "/images/maternity/gown-4.png",
        "images": [
            "/images/maternity/gown-4.png"
        ],
        "description": "A majestic royal silk draped maternity gown featuring cascading pleats and a soft empire line. Perfect for maternity portrait sessions and evening baby shower celebrations.",
        "shortDescription": "Royal silk draped maternity gown with cascading pleats.",
        "details": [
            "Stretchable Silk Georgette & Muslin Lining",
            "Empire waist line with custom fitting"
        ]
    },
    {
        "id": "prod-maternity-05",
        "slug": "mira-satin-flared-maternity-dress",
        "name": "Mira Satin Flared Maternity Photoshoot Dress",
        "category": "maternity-gowns",
        "categoryName": "Maternity Gowns",
        "chapter": "her-motherhood",
        "chapterName": "Her Motherhood",
        "price": 7499,
        "originalPrice": 9299,
        "discount": "20% OFF",
        "featured": false,
        "status": "published",
        "image": "/images/maternity/gown-5.png",
        "images": [
            "/images/maternity/gown-5.png"
        ],
        "description": "Luminous satin flared maternity dress crafted with smooth breathable inner layers and elegant long sleeves. Designed to highlight the divine mother's silhouette in every photo.",
        "shortDescription": "Luminous satin flared maternity photoshoot dress with long sleeves.",
        "details": [
            "Luminous Satin & Soft Breathable Lining",
            "Flexible waistband for all trimesters"
        ]
    },
    {
        "id": "prod-maternity-06",
        "slug": "anandi-chiffon-trail-maternity-gown",
        "name": "Anandi Chiffon Trail Maternity Occasion Gown",
        "category": "maternity-gowns",
        "categoryName": "Maternity Gowns",
        "chapter": "her-motherhood",
        "chapterName": "Her Motherhood",
        "price": 8999,
        "originalPrice": 11199,
        "discount": "20% OFF",
        "featured": true,
        "status": "published",
        "image": "/images/maternity/gown-6.png",
        "images": [
            "/images/maternity/gown-6.png"
        ],
        "description": "Ethereal chiffon maternity gown with an extended dramatic trail and hand-embroidered bodice detail. Ideal for outdoor maternity shoots and special ceremonies.",
        "shortDescription": "Ethereal chiffon maternity gown with dramatic trail.",
        "details": [
            "Pure Sheer Chiffon & Cotton Under-lining",
            "Custom trail length upon request"
        ]
    },
    {
        "id": "prod-maternity-07",
        "slug": "niharika-embellished-baby-shower-gown",
        "name": "Niharika Embellished Velvet Baby Shower Gown",
        "category": "maternity-gowns",
        "categoryName": "Maternity Gowns",
        "chapter": "her-motherhood",
        "chapterName": "Her Motherhood",
        "price": 9499,
        "originalPrice": 11799,
        "discount": "19% OFF",
        "featured": false,
        "status": "published",
        "image": "/images/maternity/gown-7.png",
        "images": [
            "/images/maternity/gown-7.png"
        ],
        "description": "Luxurious embellished maternity gown with delicate neck threadwork and an adaptable waist design. Pure comfort wrapped in high-fashion couture.",
        "shortDescription": "Embellished velvet maternity gown for baby shower events.",
        "details": [
            "Ultra-soft Velvet & Breathable Cotton Base",
            "Hidden zip for ease & comfort"
        ]
    },
    {
        "id": "prod-maternity-08",
        "slug": "sia-ethereal-organza-cape-maternity-gown",
        "name": "Sia Ethereal Organza Cape Maternity Gown",
        "category": "maternity-gowns",
        "categoryName": "Maternity Gowns",
        "chapter": "her-motherhood",
        "chapterName": "Her Motherhood",
        "price": 7299,
        "originalPrice": 9099,
        "discount": "20% OFF",
        "featured": false,
        "status": "published",
        "image": "/images/maternity/gown-8.png",
        "images": [
            "/images/maternity/gown-8.png"
        ],
        "description": "Organza cape maternity gown with flowy silhouette and sheer embroidered sleeves. Designed for supreme comfort and camera-ready grace.",
        "shortDescription": "Organza cape maternity gown with sheer embroidered sleeves.",
        "details": [
            "Pure Sheer Organza & Soft Cotton Lining",
            "Trimester expansion panel"
        ]
    },
    {
        "id": "prod-maternity-09",
        "slug": "tara-emerald-silk-flared-maternity-gown",
        "name": "Tara Emerald Silk Flared Maternity Gown",
        "category": "maternity-gowns",
        "categoryName": "Maternity Gowns",
        "chapter": "her-motherhood",
        "chapterName": "Her Motherhood",
        "price": 8299,
        "originalPrice": 10299,
        "discount": "20% OFF",
        "featured": true,
        "status": "published",
        "image": "/images/maternity/gown-9.png",
        "images": [
            "/images/maternity/gown-9.png"
        ],
        "description": "Deep emerald silk maternity gown featuring a sweetheart neck accent and floor-length flared skirt. Perfect for formal maternity dinners.",
        "shortDescription": "Emerald silk maternity gown with sweetheart neck accent.",
        "details": [
            "Viscose Silk & Cotton Under-layer",
            "Elasticated empire back"
        ]
    },
    {
        "id": "prod-maternity-10",
        "slug": "yashvi-rose-gold-sequin-maternity-dress",
        "name": "Yashvi Rose Gold Sequin Maternity Dress",
        "category": "maternity-gowns",
        "categoryName": "Maternity Gowns",
        "chapter": "her-motherhood",
        "chapterName": "Her Motherhood",
        "price": 9999,
        "originalPrice": 12499,
        "discount": "20% OFF",
        "featured": false,
        "status": "published",
        "image": "/images/maternity/gown-10.png",
        "images": [
            "/images/maternity/gown-10.png"
        ],
        "description": "Rose gold sequined maternity gown with soft inner stretch lining and a delicate V-neckline. Glamorous gown for maternity celebrations.",
        "shortDescription": "Rose gold sequined maternity gown with soft stretch lining.",
        "details": [
            "Micro-sequin Net & Soft Stretch Lining",
            "Concealed nursing zip"
        ]
    },
    {
        "id": "prod-maternity-11",
        "slug": "devi-soft-lavender-lace-maternity-gown",
        "name": "Devi Soft Lavender Lace Maternity Gown",
        "category": "maternity-gowns",
        "categoryName": "Maternity Gowns",
        "chapter": "her-motherhood",
        "chapterName": "Her Motherhood",
        "price": 6499,
        "originalPrice": 8099,
        "discount": "20% OFF",
        "featured": false,
        "status": "published",
        "image": "/images/maternity/gown-11.png",
        "images": [
            "/images/maternity/gown-11.png"
        ],
        "description": "Soft lavender lace maternity gown with sheer scalloped hem and adjustable empire waist string. Dreamy pastel palette for photoshoots.",
        "shortDescription": "Soft lavender lace maternity gown with scalloped hem.",
        "details": [
            "French Chantilly Lace & Cotton Jersey Lining",
            "Adjustable waist string"
        ]
    },
    {
        "id": "prod-maternity-12",
        "slug": "chhaya-ivory-pearl-maternity-gown",
        "name": "Chhaya Ivory Pearl Embellished Maternity Gown",
        "category": "maternity-gowns",
        "categoryName": "Maternity Gowns",
        "chapter": "her-motherhood",
        "chapterName": "Her Motherhood",
        "price": 10499,
        "originalPrice": 12999,
        "discount": "20% OFF",
        "featured": true,
        "status": "published",
        "image": "/images/maternity/gown-12.png",
        "images": [
            "/images/maternity/gown-12.png"
        ],
        "description": "Ivory silk maternity gown hand-embroidered with delicate pearl beads and gold sequins. Pure elegance for royal maternity shoots.",
        "shortDescription": "Ivory silk maternity gown with pearl bead embroidery.",
        "details": [
            "Pure Tissue Silk & Muslin Lining",
            "Hand-stitched faux pearls"
        ]
    },
    {
        "id": "prod-09",
        "slug": "nirmal-miniature-bridal-lehenga-baby",
        "name": "Nirmal Miniature Rose Baby Lehenga Set",
        "category": "baby-clothes",
        "categoryName": "Baby Clothes",
        "chapter": "her-little-one",
        "chapterName": "Her Little One",
        "price": 5999,
        "originalPrice": 7499,
        "discount": "20% OFF",
        "featured": true,
        "status": "published",
        "image": "https://images.pexels.com/photos/37182288/pexels-photo-37182288.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/37182288/pexels-photo-37182288.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "A dream in miniature! Soft organza and Malmal cotton lined baby lehenga choli set in muted rose pink. Zero-scratch seams and ultra-soft elastic band designed specifically for delicate infant skin.",
        "shortDescription": "Zero-scratch skin-friendly miniature baby lehenga in rose pink.",
        "details": [
            "100% Cotton Lined Silk & Organza",
            "Mommy & Me matching option available"
        ]
    },
    {
        "id": "prod-10",
        "slug": "choti-princess-zari-kurti-skirt-set",
        "name": "Choti Princess Gold Zari Baby Kurti Set",
        "category": "baby-clothes",
        "categoryName": "Baby Clothes",
        "chapter": "her-little-one",
        "chapterName": "Her Little One",
        "price": 4999,
        "originalPrice": 6299,
        "discount": "20% OFF",
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/37213268/pexels-photo-37213268.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/37213268/pexels-photo-37213268.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Festive ivory and gold zari baby kurti paired with twirl-worthy flared skirt. Lightweight, lined with soft muslin, perfect for first Diwali, Annaprashan, or family weddings.",
        "shortDescription": "Ivory & gold zari baby kurti set lined with soft muslin.",
        "details": [
            "Soft Muslin Cotton & Jacquard Silk",
            "Matching headband included"
        ]
    },
    {
        "id": "prod-11",
        "slug": "aarohi-peach-georgette-anarkali",
        "name": "Aarohi Peach Georgette Anarkali",
        "category": "suits-anarkalis",
        "categoryName": "Suits & Anarkalis",
        "chapter": "her-beginnings",
        "chapterName": "Her Beginnings",
        "price": 5999,
        "originalPrice": 7499,
        "discount": "20% OFF",
        "newArrival": true,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/4048041/pexels-photo-4048041.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/4048041/pexels-photo-4048041.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Flowy peach georgette flared Anarkali with gold thread jaal embroidery all over. Comes with a matching georgette dupatta with hand-stitched tassel ends.",
        "shortDescription": "Peach georgette Anarkali with gold jaal embroidery & tassel dupatta.",
        "details": [
            "Pure Georgette & Dupatta Included",
            "Full customization on fit & sleeve style"
        ]
    },
    {
        "id": "prod-12",
        "slug": "lavanya-lilac-chanderi-palazzo-suit",
        "name": "Lavanya Lilac Chanderi Palazzo Suit",
        "category": "suits-anarkalis",
        "categoryName": "Suits & Anarkalis",
        "chapter": "her-beginnings",
        "chapterName": "Her Beginnings",
        "price": 5499,
        "originalPrice": 6999,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/4048042/pexels-photo-4048042.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/4048042/pexels-photo-4048042.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Soft lilac Chanderi cotton kurta with minimal Lucknowi chikankari patterns, paired with wide palazzo pants and a sheer organza dupatta.",
        "shortDescription": "Lilac Chanderi chikankari kurta with wide palazzo & organza dupatta.",
        "details": [
            "Chanderi Cotton & Organza Dupatta",
            "Palazzo width & kurta length customizable"
        ]
    },
    {
        "id": "prod-13",
        "slug": "rania-deep-maroon-raw-silk-suit",
        "name": "Rania Deep Maroon Raw Silk Suit",
        "category": "suits-anarkalis",
        "categoryName": "Suits & Anarkalis",
        "chapter": "her-beginnings",
        "chapterName": "Her Beginnings",
        "price": 8999,
        "originalPrice": 10999,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": true,
        "status": "published",
        "image": "https://images.pexels.com/photos/20690519/pexels-photo-20690519.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/20690519/pexels-photo-20690519.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Rich deep maroon raw silk straight-cut kurta set with heavy neck embroidery, gold kaam highlights, and a banarasi brocade dupatta with gold border.",
        "shortDescription": "Maroon raw silk kurta with gold kaam & banarasi dupatta.",
        "details": [
            "Raw Silk & Banarasi Brocade Dupatta",
            "Gold zari neckline embroidery"
        ]
    },
    {
        "id": "prod-14",
        "slug": "arjun-powder-blue-mirror-kurta",
        "name": "Mehal Powder Blue Mirror Kurta Set",
        "category": "suits-anarkalis",
        "categoryName": "Suits & Anarkalis",
        "chapter": "her-beginnings",
        "chapterName": "Her Beginnings",
        "price": 4999,
        "originalPrice": 6299,
        "discount": "20% OFF",
        "newArrival": true,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/20407233/pexels-photo-20407233.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/20407233/pexels-photo-20407233.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Festive powder blue cotton kurta adorned with intricate handmade mirror work on yoke and sleeves, paired with palazzo pants.",
        "shortDescription": "Powder blue mirror-work cotton kurta with palazzo pants.",
        "details": [
            "Handblock Cotton & Kora Dupatta",
            "Mirror work hand-stitched by artisans"
        ]
    },
    {
        "id": "prod-15",
        "slug": "saffron-floral-anarkali-set",
        "name": "Suraj Saffron Floral Anarkali Set",
        "category": "suits-anarkalis",
        "categoryName": "Suits & Anarkalis",
        "chapter": "her-beginnings",
        "chapterName": "Her Beginnings",
        "price": 5799,
        "originalPrice": 7299,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/20407198/pexels-photo-20407198.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/20407198/pexels-photo-20407198.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Vivid saffron floral printed Anarkali in breathable mul-mul cotton, ideal for festive events. Embellished with handcrafted pom-pom dupatta.",
        "shortDescription": "Saffron floral mul-mul Anarkali with pom-pom dupatta.",
        "details": [
            "Hand-printed Mul-mul Cotton",
            "Festive all-occasion wear"
        ]
    },
    {
        "id": "prod-16",
        "slug": "ivory-zardozi-straight-kurta",
        "name": "Shagun Ivory Zardozi Straight Kurta",
        "category": "suits-anarkalis",
        "categoryName": "Suits & Anarkalis",
        "chapter": "her-beginnings",
        "chapterName": "Her Beginnings",
        "price": 9499,
        "originalPrice": 11999,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/33363057/pexels-photo-33363057.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/33363057/pexels-photo-33363057.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Bridal reception-worthy ivory silk straight kurta featuring heavy Zardozi goldwork bodice, paired with wide-leg silk pants and a sheer embroidered dupatta.",
        "shortDescription": "Ivory silk Zardozi kurta with silk pants & embroidered dupatta.",
        "details": [
            "Pure Silk & Sheer Net Dupatta",
            "Heavy Zardozi gold hand embroidery"
        ]
    },
    {
        "id": "prod-17",
        "slug": "forest-green-organza-anarkali",
        "name": "Vana Forest Green Organza Anarkali",
        "category": "suits-anarkalis",
        "categoryName": "Suits & Anarkalis",
        "chapter": "her-beginnings",
        "chapterName": "Her Beginnings",
        "price": 7499,
        "originalPrice": 9299,
        "discount": "20% OFF",
        "newArrival": true,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/20690539/pexels-photo-20690539.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/20690539/pexels-photo-20690539.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Dramatic forest green organza Anarkali gown with hand-embroidered floral sprigs and a trail. Perfect for evening functions and sangeet nights.",
        "shortDescription": "Forest green organza Anarkali gown with trail & floral embroidery.",
        "details": [
            "Layered Organza & Inner Lining",
            "Trail length customizable"
        ]
    },
    {
        "id": "prod-18",
        "slug": "dusty-rose-lucknowi-anarkali",
        "name": "Mehram Dusty Rose Lucknowi Anarkali",
        "category": "suits-anarkalis",
        "categoryName": "Suits & Anarkalis",
        "chapter": "her-beginnings",
        "chapterName": "Her Beginnings",
        "price": 5299,
        "originalPrice": 6599,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/34933700/pexels-photo-34933700.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/34933700/pexels-photo-34933700.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Classic dusty rose Lucknowi chikan embroidered Anarkali kurta with delicate white threadwork. Timeless everyday elegance for family functions.",
        "shortDescription": "Dusty rose Lucknowi chikankari Anarkali for everyday elegance.",
        "details": [
            "Mul-mul Georgette & Chikankari Threadwork",
            "Dry clean for longevity"
        ]
    },
    {
        "id": "prod-19",
        "slug": "crimson-velvet-bridal-lehenga",
        "name": "Maharani Crimson Velvet Bridal Lehenga",
        "category": "bridal-lehengas",
        "categoryName": "Bridal Lehengas",
        "chapter": "her-forever",
        "chapterName": "Her Forever",
        "price": 10499,
        "originalPrice": 12999,
        "discount": "19% OFF",
        "newArrival": false,
        "featured": true,
        "status": "published",
        "image": "https://images.pexels.com/photos/20790059/pexels-photo-20790059.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/20790059/pexels-photo-20790059.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Regal crimson velvet bridal lehenga with all-over kundan stonework and antique gold dabka embroidery. Paired with velvet blouse and double net dupattas with intricate borders.",
        "shortDescription": "Crimson velvet kundan bridal lehenga with double dupattas.",
        "details": [
            "Pure Velvet Silk",
            "Custom kundan placement available",
            "Personalized date embroidery on dupatta"
        ]
    },
    {
        "id": "prod-20",
        "slug": "blush-pink-sequin-bridal",
        "name": "Rukmini Blush Pink Sequin Bridal Lehenga",
        "category": "bridal-lehengas",
        "categoryName": "Bridal Lehengas",
        "chapter": "her-forever",
        "chapterName": "Her Forever",
        "price": 9999,
        "originalPrice": 12499,
        "discount": "22% OFF",
        "newArrival": true,
        "featured": true,
        "status": "published",
        "image": "https://images.pexels.com/photos/20790061/pexels-photo-20790061.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/20790061/pexels-photo-20790061.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Dreamy blush pink lehenga with all-over sequin work and subtle floral cutwork on skirt. Light as a feather for the modern bride who wants to dance the night.",
        "shortDescription": "All-over sequin blush pink bridal lehenga for the modern bride.",
        "details": [
            "Lightweight Sequin Net",
            "Blouse back customizable",
            "Custom waist fitting"
        ]
    },
    {
        "id": "prod-21",
        "slug": "ivory-gold-banarasi-bridal",
        "name": "Swarna Ivory Gold Banarasi Bridal Lehenga",
        "category": "bridal-lehengas",
        "categoryName": "Bridal Lehengas",
        "chapter": "her-forever",
        "chapterName": "Her Forever",
        "price": 10799,
        "originalPrice": 13499,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/29336849/pexels-photo-29336849.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/29336849/pexels-photo-29336849.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Timeless ivory and gold Banarasi silk bridal lehenga woven with real gold zari. A generational heirloom piece designed for the bride who chooses heritage over trend.",
        "shortDescription": "Ivory Banarasi silk bridal lehenga with real gold zari weave.",
        "details": [
            "Real Gold Zari Woven Silk",
            "Heirloom quality weave from Varanasi",
            "Custom hem & blouse design"
        ]
    },
    {
        "id": "prod-22",
        "slug": "midnight-blue-embroidered-bridal",
        "name": "Neelambar Midnight Blue Embroidered Lehenga",
        "category": "bridal-lehengas",
        "categoryName": "Bridal Lehengas",
        "chapter": "her-forever",
        "chapterName": "Her Forever",
        "price": 9499,
        "originalPrice": 11999,
        "discount": "20% OFF",
        "newArrival": true,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/28144267/pexels-photo-28144267.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/28144267/pexels-photo-28144267.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Striking midnight blue raw silk bridal lehenga with silver aari embroidery, metallic sequins and a contrast gold dupatta. For the bold modern bride.",
        "shortDescription": "Midnight blue silk lehenga with silver aari & metallic sequins.",
        "details": [
            "Raw Silk & Gold Georgette Dupatta",
            "Aari embroidery by artisans"
        ]
    },
    {
        "id": "prod-23",
        "slug": "coral-ombre-bridal-lehenga",
        "name": "Sandhya Coral Ombré Bridal Lehenga",
        "category": "bridal-lehengas",
        "categoryName": "Bridal Lehengas",
        "chapter": "her-forever",
        "chapterName": "Her Forever",
        "price": 8999,
        "originalPrice": 11299,
        "discount": "21% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/30495732/pexels-photo-30495732.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/30495732/pexels-photo-30495732.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Sunset ombré coral-to-peach hand-dyed silk lehenga with resham floral butti all over and a sequin belt waistband. Sangeet & reception perfect.",
        "shortDescription": "Coral ombré silk bridal lehenga with floral butti & sequin belt.",
        "details": [
            "Hand-dyed Pure Silk",
            "Resham butti embroidered",
            "Comes with matching choker"
        ]
    },
    {
        "id": "prod-24",
        "slug": "pastel-mint-bridal-lehenga",
        "name": "Sheetla Pastel Mint Bridal Lehenga",
        "category": "bridal-lehengas",
        "categoryName": "Bridal Lehengas",
        "chapter": "her-forever",
        "chapterName": "Her Forever",
        "price": 9299,
        "originalPrice": 11599,
        "discount": "20% OFF",
        "newArrival": true,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/36951188/pexels-photo-36951188.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/36951188/pexels-photo-36951188.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Unconventional pastel mint silk lehenga with dense platinum-tone gota patti borders and fine cutwork skirt panels. Perfect for the fashion-forward bride.",
        "shortDescription": "Pastel mint silk bridal lehenga with platinum gota patti borders.",
        "details": [
            "Pure Silk Mikado & Net Blouse",
            "Platinum zari gota weave"
        ]
    },
    {
        "id": "prod-25",
        "slug": "royal-wine-velvet-bridal",
        "name": "Aahana Royal Wine Velvet Lehenga",
        "category": "bridal-lehengas",
        "categoryName": "Bridal Lehengas",
        "chapter": "her-forever",
        "chapterName": "Her Forever",
        "price": 10899,
        "originalPrice": 13599,
        "discount": "18% OFF",
        "newArrival": false,
        "featured": true,
        "status": "published",
        "image": "https://images.pexels.com/photos/32212943/pexels-photo-32212943.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/32212943/pexels-photo-32212943.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Rich wine velvet bridal lehenga adorned with silver kundan stonework and maroon resham embroidery. A statement piece for winter weddings.",
        "shortDescription": "Wine velvet bridal lehenga with silver kundan for winter weddings.",
        "details": [
            "Pure Velvet & Brocade Dupatta",
            "Custom fit in 4 weeks"
        ]
    },
    {
        "id": "prod-26",
        "slug": "golden-tissue-silk-bridal-lehenga",
        "name": "Hiranya Golden Tissue Silk Lehenga",
        "category": "bridal-lehengas",
        "categoryName": "Bridal Lehengas",
        "chapter": "her-forever",
        "chapterName": "Her Forever",
        "price": 10599,
        "originalPrice": 13299,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/33343613/pexels-photo-33343613.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/33343613/pexels-photo-33343613.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Shimmering golden tissue silk lehenga with all-over sequin & stone embellishment. Creates a breathtaking luminous effect for high-candlelight receptions.",
        "shortDescription": "Golden tissue silk lehenga with all-over sequin & stone work.",
        "details": [
            "Tissue Silk with Full Lining",
            "Velvet blouse included"
        ]
    },
    {
        "id": "prod-27",
        "slug": "sunshine-yellow-peplum-lehenga",
        "name": "Basant Sunshine Yellow Peplum Lehenga",
        "category": "haldi-mehendi",
        "categoryName": "Haldi & Mehendi",
        "chapter": "her-new-chapter",
        "chapterName": "Her New Chapter",
        "price": 6999,
        "originalPrice": 8699,
        "discount": "20% OFF",
        "newArrival": true,
        "featured": true,
        "status": "published",
        "image": "https://images.pexels.com/photos/38563263/pexels-photo-38563263.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/38563263/pexels-photo-38563263.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Vibrant sunshine yellow peplum kurta with mirror-sequin work, paired with a voluminous flared lehenga skirt in matching cotton silk. Designed for Haldi rituals.",
        "shortDescription": "Sunshine yellow peplum kurta with mirror lehenga skirt for Haldi.",
        "details": [
            "Cotton Silk",
            "Mirror work & sequin embellishment",
            "Matching jutis available"
        ]
    },
    {
        "id": "prod-28",
        "slug": "olive-green-mehendi-anarkali",
        "name": "Vriksha Olive Green Mehendi Anarkali",
        "category": "haldi-mehendi",
        "categoryName": "Haldi & Mehendi",
        "chapter": "her-new-chapter",
        "chapterName": "Her New Chapter",
        "price": 7799,
        "originalPrice": 9699,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/17635596/pexels-photo-17635596.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/17635596/pexels-photo-17635596.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Regal olive green floor-length Anarkali with intricate gold zari embroidery, ideal for evening mehendi functions and sangeet nights.",
        "shortDescription": "Olive green Anarkali with gold zari for Mehendi & Sangeet.",
        "details": [
            "Viscose Georgette",
            "Gold zari tasselled dupatta included"
        ]
    },
    {
        "id": "prod-29",
        "slug": "tangerine-mirror-sharara",
        "name": "Narangi Tangerine Mirror Sharara Set",
        "category": "haldi-mehendi",
        "categoryName": "Haldi & Mehendi",
        "chapter": "her-new-chapter",
        "chapterName": "Her New Chapter",
        "price": 6499,
        "originalPrice": 8099,
        "discount": "20% OFF",
        "newArrival": true,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/31750751/pexels-photo-31750751.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/31750751/pexels-photo-31750751.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Festive tangerine orange short kurta with dense hand-stitched mirror work and a dramatic gathered sharara paired with a kora organza dupatta.",
        "shortDescription": "Tangerine mirror-work sharara set for festive Haldi/Mehendi occasions.",
        "details": [
            "Viscose Silk & Kora Organza",
            "Hand-stitched mirrors by craftswomen"
        ]
    },
    {
        "id": "prod-30",
        "slug": "floral-pink-mehendi-lehnga",
        "name": "Pushpa Floral Pink Mehendi Lehenga",
        "category": "haldi-mehendi",
        "categoryName": "Haldi & Mehendi",
        "chapter": "her-new-chapter",
        "chapterName": "Her New Chapter",
        "price": 7299,
        "originalPrice": 9099,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/12992093/pexels-photo-12992093.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/12992093/pexels-photo-12992093.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Blush floral block-printed lehenga with gota patti borders and a sheer scalloped dupatta. Perfect for outdoor daytime Mehendi ceremonies.",
        "shortDescription": "Floral block-print pink lehenga with gota borders for daytime Mehendi.",
        "details": [
            "Handblock Cotton Silk",
            "Scalloped dupatta with mirror tassels"
        ]
    },
    {
        "id": "prod-31",
        "slug": "turquoise-bandhani-sharara",
        "name": "Dhaani Turquoise Bandhani Sharara",
        "category": "haldi-mehendi",
        "categoryName": "Haldi & Mehendi",
        "chapter": "her-new-chapter",
        "chapterName": "Her New Chapter",
        "price": 5999,
        "originalPrice": 7499,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/29873544/pexels-photo-29873544.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/29873544/pexels-photo-29873544.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Vibrant turquoise bandhani tie-dye sharara set with gold printed borders and a crushed dupatta. A playful, festive choice for Haldi or casual functions.",
        "shortDescription": "Turquoise bandhani sharara set with gold printed borders.",
        "details": [
            "Rajasthani Gaji Silk Bandhani",
            "Dupatta with embroidered hem"
        ]
    },
    {
        "id": "prod-32",
        "slug": "saffron-green-haldi-lehenga",
        "name": "Tilak Saffron & Green Haldi Lehenga",
        "category": "haldi-mehendi",
        "categoryName": "Haldi & Mehendi",
        "chapter": "her-new-chapter",
        "chapterName": "Her New Chapter",
        "price": 7499,
        "originalPrice": 9299,
        "discount": "20% OFF",
        "newArrival": true,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/37847010/pexels-photo-37847010.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/37847010/pexels-photo-37847010.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Traditional saffron-and-green colour-blocked raw silk Haldi lehenga with gold zari borders and a sequin choli blouse. Perfect for outdoor Haldi rituals.",
        "shortDescription": "Saffron-green raw silk Haldi lehenga with gold zari & sequin blouse.",
        "details": [
            "Raw Silk & Cotton Under-skirt",
            "Elasticated waist for comfort"
        ]
    },
    {
        "id": "prod-33",
        "slug": "marigold-embroidered-set",
        "name": "Marigold Embroidered Ethnic Ensemble",
        "category": "haldi-mehendi",
        "categoryName": "Haldi & Mehendi",
        "chapter": "her-new-chapter",
        "chapterName": "Her New Chapter",
        "price": 8299,
        "originalPrice": 10299,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/35591654/pexels-photo-35591654.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/35591654/pexels-photo-35591654.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Marigold yellow kurta with dense resham floral embroidery paired with a wide flared skirt and kota dupatta. Complete festive ensemble.",
        "shortDescription": "Marigold yellow kurta with resham embroidery & flared skirt.",
        "details": [
            "Katan Silk & Kota Dupatta",
            "Embroidered by artisan craftswomen"
        ]
    },
    {
        "id": "prod-34",
        "slug": "choti-rani-red-banarasi-baby",
        "name": "Choti Rani Red Banarasi Baby Lehenga",
        "category": "baby-clothes",
        "categoryName": "Baby Clothes",
        "chapter": "her-little-one",
        "chapterName": "Her Little One",
        "price": 5499,
        "originalPrice": 6899,
        "discount": "20% OFF",
        "newArrival": true,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/8818761/pexels-photo-8818761.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/8818761/pexels-photo-8818761.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Miniature red Banarasi brocade baby lehenga with gold zari borders and a soft muslin inner lining. Designed for first Diwali, Namakarana and baby naming ceremonies.",
        "shortDescription": "Red Banarasi baby lehenga with gold zari & muslin inner lining.",
        "details": [
            "Banarasi Brocade & Muslin Lining",
            "Zero-scratch seams, 100% cotton lined"
        ]
    },
    {
        "id": "prod-35",
        "slug": "royal-blue-baby-sherwani-set",
        "name": "Shehzada Royal Blue Baby Sherwani Set",
        "category": "baby-clothes",
        "categoryName": "Baby Clothes",
        "chapter": "her-little-one",
        "chapterName": "Her Little One",
        "price": 4999,
        "originalPrice": 6199,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/12100636/pexels-photo-12100636.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/12100636/pexels-photo-12100636.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Miniature royal blue jacquard sherwani set with a matching churidar and embroidered dupatta. For baby boys at family weddings and religious ceremonies.",
        "shortDescription": "Royal blue jacquard baby sherwani set with churidar for boys.",
        "details": [
            "Jacquard Silk & Cotton Lining",
            "Includes sherwani, churidar & stole"
        ]
    },
    {
        "id": "prod-36",
        "slug": "mint-green-annaprashan-baby-set",
        "name": "Prashasan Mint Green Annaprashan Set",
        "category": "baby-clothes",
        "categoryName": "Baby Clothes",
        "chapter": "her-little-one",
        "chapterName": "Her Little One",
        "price": 5199,
        "originalPrice": 6499,
        "discount": "20% OFF",
        "newArrival": true,
        "featured": true,
        "status": "published",
        "image": "https://images.pexels.com/photos/12100639/pexels-photo-12100639.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/12100639/pexels-photo-12100639.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Tender mint green cotton silk baby dress for Annaprashan ceremony, adorned with gold piping and a hand-smocked bodice. Hypoallergenic, soft, and stretchable.",
        "shortDescription": "Mint green Annaprashan baby dress with gold piping & smocking.",
        "details": [
            "100% Cotton Silk & Hypoallergenic",
            "Stretchable for easy dressing"
        ]
    },
    {
        "id": "prod-37",
        "slug": "mommy-me-haldi-set",
        "name": "Mommy & Me Haldi Matching Set",
        "category": "baby-clothes",
        "categoryName": "Baby Clothes",
        "chapter": "her-little-one",
        "chapterName": "Her Little One",
        "price": 8999,
        "originalPrice": 11199,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": true,
        "status": "published",
        "image": "https://images.pexels.com/photos/18983042/pexels-photo-18983042.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/18983042/pexels-photo-18983042.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Coordinating Mommy & Me set — mother lehenga and baby lehenga in matching sunshine yellow cotton with identical embroidery and gota patti borders.",
        "shortDescription": "Matching Mommy & Baby Haldi yellow lehenga set.",
        "details": [
            "Cotton Silk",
            "Available in 0–12 months baby sizes",
            "Can extend to 3 years"
        ]
    },
    {
        "id": "prod-38",
        "slug": "peach-organza-baby-frock",
        "name": "Mithi Peach Organza Baby Frock Set",
        "category": "baby-clothes",
        "categoryName": "Baby Clothes",
        "chapter": "her-little-one",
        "chapterName": "Her Little One",
        "price": 4999,
        "originalPrice": 5999,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/15142195/pexels-photo-15142195.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/15142195/pexels-photo-15142195.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Peach organza baby dress with tulle layers, satin bow and featherlight skirt for baby girls. Perfect for birthday parties, namkaran and christening ceremonies.",
        "shortDescription": "Peach organza baby girl party frock with tulle layers & satin bow.",
        "details": [
            "Organza & Tulle with Cotton Lining",
            "Adjustable back button"
        ]
    },
    {
        "id": "prod-39",
        "slug": "saffron-baby-jamdani-kurta-set",
        "name": "Tara Saffron Jamdani Baby Kurta Set",
        "category": "baby-clothes",
        "categoryName": "Baby Clothes",
        "chapter": "her-little-one",
        "chapterName": "Her Little One",
        "price": 4999,
        "originalPrice": 6199,
        "discount": "20% OFF",
        "newArrival": true,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/15213328/pexels-photo-15213328.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/15213328/pexels-photo-15213328.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Handwoven saffron Jamdani baby kurta set with dhoti pants. Ultra-breathable heritage fabric for India's hot climate. Ideal for religious and festive occasions.",
        "shortDescription": "Handwoven saffron Jamdani baby kurta set with dhoti pants.",
        "details": [
            "Heritage Jamdani Cotton",
            "Unisex style for boys & girls"
        ]
    },
    {
        "id": "prod-40",
        "slug": "dainty-lavender-baby-anarkali",
        "name": "Dainty Lavender Baby Anarkali Set",
        "category": "baby-clothes",
        "categoryName": "Baby Clothes",
        "chapter": "her-little-one",
        "chapterName": "Her Little One",
        "price": 5299,
        "originalPrice": 6599,
        "discount": "20% OFF",
        "newArrival": false,
        "featured": false,
        "status": "published",
        "image": "https://images.pexels.com/photos/16237026/pexels-photo-16237026.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images": [
            "https://images.pexels.com/photos/16237026/pexels-photo-16237026.jpeg?auto=compress&cs=tinysrgb&w=1200"
        ],
        "description": "Sweet lavender baby anarkali set for baby girls aged 0–3 years. Features soft flared skirt, elastic waistband, and micro mirror embroidery buttons.",
        "shortDescription": "Lavender baby anarkali with mirror buttons for 0–3 year olds.",
        "details": [
            "100% Cotton",
            "Mirror button embroidery",
            "0–3 years"
        ]
    }
];

export const initialGallery = [
    {
        "id": "lb-01",
        "title": "Mughal Rose Bridal Story",
        "category": "Bridal",
        "image": "https://images.pexels.com/photos/32081698/pexels-photo-32081698.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "aspectRatio": "aspect-[3/4]",
        "location": "Studio New Delhi"
    },
    {
        "id": "lb-02",
        "title": "Golden Hour Haldi Splendor",
        "category": "Festive",
        "image": "https://images.pexels.com/photos/30931265/pexels-photo-30931265.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "aspectRatio": "aspect-[4/5]",
        "location": "Garden Courtyard"
    },
    {
        "id": "lb-03",
        "title": "Motherhood Grace & Silks",
        "category": "Maternity",
        "image": "/images/maternity/gown-5.png",
        "aspectRatio": "aspect-[3/4]",
        "location": "New Delhi Atelier"
    },
    {
        "id": "lb-04",
        "title": "First Celebrations & Baby Heirloom",
        "category": "Baby",
        "image": "https://wholesalemegamart.com/wp-content/uploads/2026/04/ZSR-3169-KIDS-ETHNIC-WEAR-FOR-GIRLS-WHOLESALE-1.jpeg",
        "aspectRatio": "aspect-[1/1]",
        "location": "Boutique Lounge"
    },
    {
        "id": "lb-05",
        "title": "Gulzar Anarkali Flow",
        "category": "Suits",
        "image": "https://images.pexels.com/photos/14784502/pexels-photo-14784502.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "aspectRatio": "aspect-[3/4]",
        "location": "Heritage Suite"
    },
    {
        "id": "lb-06",
        "title": "Mehendi Emerald Splendor",
        "category": "Festive",
        "image": "https://images.pexels.com/photos/31750737/pexels-photo-31750737.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "aspectRatio": "aspect-[4/5]",
        "location": "New Delhi Studio"
    }
];

export const initialOffers = [
    {
        id: "offer-1",
        title: "Festive Bridal Preview Discount",
        code: "BRIDAL2026",
        discountPercent: 15,
        description: "Exclusive 15% bespoke discount on all pre-booked Bridal Lehengas.",
        applicableCategory: "bridal-lehengas",
        active: true,
        startDate: "2026-08-01",
        endDate: "2026-10-31",
    }
];

export const products = initialProducts;
export const lookbookItems = initialGallery;

// Client & SSR compatible data getters
export function getProducts() {
    return initialProducts;
}

export function getFeaturedProducts() {
    return getProducts().filter((p) => p.featured);
}

export function getProductBySlug(slug) {
    return getProducts().find((p) => p.slug === slug || p.id === slug);
}

export function getProductsByCategory(categorySlug) {
    const all = getProducts();
    if (!categorySlug || categorySlug === "all") return all;
    return all.filter((p) => p.category === categorySlug || p.categorySlug === categorySlug);
}

export function getRelatedProducts(currentSlug, limit = 3) {
    const all = getProducts();
    const current = all.find((p) => p.slug === currentSlug || p.id === currentSlug);
    if (!current) return all.slice(0, limit);
    const sameCat = all.filter((p) => (p.category === current.category || p.categorySlug === current.categorySlug) && p.slug !== currentSlug);
    if (sameCat.length >= limit) return sameCat.slice(0, limit);
    const remaining = all.filter((p) => p.slug !== currentSlug && !sameCat.includes(p));
    return [...sameCat, ...remaining].slice(0, limit);
}

export function getCategories() {
    return initialCategories;
}

export function getChapters() {
    return initialChapters;
}

export function getGalleryItems() {
    return initialGallery;
}
